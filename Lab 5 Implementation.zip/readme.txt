Duong H Chau
CSS 342
lab5

My program works although it has some memory leaks.

According to the sample files in this assignment, there is one bug occurs in my program
when it processes the last transaction for CLIENT ID5555. Based on the outcome of the
client when displaying, it shows that the transaction went through but it also state that
the transaction was not successfully processed.

I am proud that the program is finally working. I am more proud when I was able to reduce the memory leaks
from 468 down to 132. If I have more time, I would definitely dicover all the bugs and leaks in my program.

Anyway, Cheers to the completion of the last Lab of the quarter.
Have a wonderful break and Holidays.
